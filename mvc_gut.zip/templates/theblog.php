<h1><?php echo $this->_['blog_title']; ?></h1>
<?php echo $this->_['blog_content']; ?>
<hr />
<?php echo $this->_['blog_footer']; ?>