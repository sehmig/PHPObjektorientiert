<h1>Willkommen im MVC-Blog!</h1>
<h2><?php echo $this->_['title']; ?></h2>
<p><?php echo $this->_['content']; ?></p>
<a href="?view=deafult">Zur&uuml;ck zur &Uuml;bersicht</a>
